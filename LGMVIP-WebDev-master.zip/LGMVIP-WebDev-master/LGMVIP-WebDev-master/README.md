# <a href="https://lgmvipwebdev-task1.netlify.app/" target="_blank">My Single Page Website Website</a>

[![Repository Status](https://img.shields.io/badge/Repository%20Status-Maintained-dark%20green.svg)](https://github.com/balajeeav/avb.github.io/)
[![Website Status](https://img.shields.io/badge/Website%20Status-Online-green)](https://lgmvipwebdev-task1.netlify.app/)
[![Author](https://img.shields.io/badge/Author-Balajee%20A%20V-red)](https://www.linkedin.com/in/balajeevg-techclog/)


 <p align="justify">LGM Virtual Internship program TASK -1 : To create a single page website using HTML , CSS & JS</p>


![My Single Page Website](https://github.com/balajeeav/LGMVIP-WebDev/blob/master/LGMVIP-WebDev-master/TASK%201%20(LEVEL%201)/AVB/Single%20page.JPG)

Leave a :star: &nbsp;if you like it!


#Coded By:
#Balajee A V

