# Let's Grow More Virtual Internship Programme


[![Repository Status](https://img.shields.io/badge/Repository%20Status-Maintained-dark%20green.svg)](https://github.com/balajeeav/LGMVIP-WebDev)
[![Author](https://img.shields.io/badge/Author-Balajee%20A%20V-red)](https://www.linkedin.com/in/balajeevg-techclog/)




![My Single Page Website](https://github.com/balajeeav/LGMVIP-WebDev/blob/master/LGMVIP-WebDev-master/TASK%201%20(LEVEL%201)/AVB/assets/img/1.JPG)
# Web Development Internship
![My Single Page Website](https://github.com/balajeeav/LGMVIP-WebDev/blob/master/LGMVIP-WebDev-master/TASK%201%20(LEVEL%201)/AVB/assets/img/3.JPG) 
# TASK-1 : TO CREATE A SINGLE PAGE WEBSITE
![My Single Page Website](https://github.com/balajeeav/LGMVIP-WebDev/blob/master/LGMVIP-WebDev-master/TASK%201%20(LEVEL%201)/AVB/assets/img/4.JPG)
# <a href="https://lgmvipwebdev-task1.netlify.app/" target="_blank">My Single Page Website Website</a>
<p align="justify">LGM Virtual Internship program TASK -1 : To create a single page website using HTML , CSS & JS</p>
# <a href="https://github.com/balajeeav/LGMVIP-WebDev/tree/master/LGMVIP-WebDev-master/TASK%201%20(LEVEL%201)/AVB" target="_blank">Link for single page rep</a>

# TASK-2 : TO CREATE WEB APPLICATION USING React-App
![My Single Page Website](https://github.com/balajeeav/LGMVIP-WebDev/blob/master/LGMVIP-WebDev-master/TASK%201%20(LEVEL%201)/AVB/assets/img/5.JPG)
<p align="justify">LGM Virtual Internship program TASK -2 : To create a Web Application using React-App (React JS)</p>
# <a href="https://github.com/balajeeav/LGMVIP-WebDev/tree/master/LGMVIP-WebDev-master/task2/task2-reactapp" target="_blank">Link for React-App Repo..</a>



>Leave a :star: &nbsp;if you like it!


>> # Coded By:
>> # Balajee A V

